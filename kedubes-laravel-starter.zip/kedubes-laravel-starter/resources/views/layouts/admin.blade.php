<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title', 'Kelola Konten') — Kedubes Studio Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<style>
  :root{
    --violet:#6c5ce7; --violet-deep:#4b3fe0;
    --gold:#b8791f; --gold-soft:#fbf3e7;
    --text:#1d1d1f; --text-muted:#6e6e73; --text-faint:#9a9ca2;
    --line:rgba(0,0,0,.08); --bg:#ffffff; --bg-soft:#f5f5f7;
    --violet-soft:#f1effd; --green:#1e8e5a; --green-soft:#e8f7f0;
    --radius-lg:20px; --radius-md:14px; --radius-sm:9px;
    --shadow-card:0 2px 5px rgba(0,0,0,.04), 0 14px 30px rgba(0,0,0,.05);
    --ease:cubic-bezier(.16,.84,.44,1);
  }
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:'Inter',system-ui,sans-serif;background:var(--bg-soft);color:var(--text);line-height:1.5;}
  h1,h2,h3,h4{font-family:'Plus Jakarta Sans',sans-serif;font-weight:700;letter-spacing:-.02em;}
  .mono{font-family:'IBM Plex Mono',monospace;}
  a{text-decoration:none;color:inherit;}
  button{font-family:inherit;cursor:pointer;}
  .seal{width:34px;height:34px;flex:none;}

  .shell{display:flex;min-height:100vh;}
  .sidebar{
    width:250px;flex:none;background:#fff;border-right:1px solid var(--line);
    display:flex;flex-direction:column;padding:22px 16px;position:sticky;top:0;height:100vh;
  }
  .sb-brand{display:flex;align-items:center;gap:10px;padding:6px 8px 22px;border-bottom:1px solid var(--line);margin-bottom:18px;}
  .sb-brand div{font-weight:700;font-size:14px;}
  .sb-brand small{display:block;font-family:'IBM Plex Mono',monospace;font-size:8.5px;letter-spacing:.1em;color:var(--gold);text-transform:uppercase;}
  .sb-label{font-family:'IBM Plex Mono',monospace;font-size:10px;letter-spacing:.1em;color:var(--text-faint);text-transform:uppercase;padding:0 10px;margin:14px 0 8px;}
  .sb-menu a{
    display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:var(--radius-sm);
    font-size:13.8px;font-weight:500;color:var(--text-muted);margin-bottom:2px;transition:.15s;
  }
  .sb-menu a:hover{background:var(--bg-soft);color:var(--text);}
  .sb-menu a.active{background:var(--violet-soft);color:var(--violet-deep);font-weight:600;}
  .sb-bottom{margin-top:auto;padding-top:14px;border-top:1px solid var(--line);}
  .sb-user{display:flex;align-items:center;gap:10px;padding:8px;border-radius:var(--radius-sm);}
  .sb-user .av{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--violet),var(--gold));flex:none;}
  .sb-user strong{font-size:12.5px;display:block;}
  .sb-user span{font-size:11px;color:var(--text-faint);}
  .sb-user .logout{margin-left:auto;color:var(--text-faint);background:none;border:0;}

  .main{flex:1;min-width:0;}
  .topbar{
    background:rgba(255,255,255,.85);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);
    padding:18px 32px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:5;
  }
  .topbar h2{font-size:19px;}
  .topbar .path{font-size:12px;color:var(--text-faint);margin-top:2px;}
  .btn-view-site{
    display:flex;align-items:center;gap:7px;padding:9px 16px;border-radius:100px;border:1px solid var(--line);
    font-size:13px;font-weight:600;background:#fff;
  }
  .content{padding:28px 32px 60px;}

  .tabs{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;}
  .tab-btn{
    padding:9px 16px;border-radius:100px;border:1px solid var(--line);background:#fff;
    font-size:13px;font-weight:600;color:var(--text-muted);
  }
  .tab-btn.active{background:var(--text);color:#fff;border-color:var(--text);}

  .card{background:#fff;border:1px solid var(--line);border-radius:var(--radius-md);box-shadow:var(--shadow-card);margin-bottom:20px;}
  .card-head{padding:18px 22px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;}
  .card-head h3{font-size:15.5px;}
  .card-head p{font-size:12.5px;color:var(--text-muted);margin-top:2px;}
  .card-body{padding:22px;}

  .btn-primary{
    display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border:0;border-radius:100px;
    font-size:13px;font-weight:600;color:#fff;background:linear-gradient(135deg,var(--violet),var(--violet-deep));
  }
  .btn-outline{padding:8px 14px;border-radius:100px;border:1px solid var(--line);background:#fff;font-size:12.5px;font-weight:600;color:var(--text-muted);}
  .btn-danger{padding:8px 14px;border-radius:100px;border:1px solid #f3d3d3;background:#fdf1f1;font-size:12.5px;font-weight:600;color:#c0392b;}

  .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;}
  .form-grid .full{grid-column:1/-1;}
  .field2{margin-bottom:2px;}
  .field2 label{display:block;font-size:12.5px;font-weight:600;margin-bottom:6px;}
  .field2 input, .field2 textarea, .field2 select{
    width:100%;padding:10px 13px;border-radius:var(--radius-sm);border:1px solid var(--line);
    font-size:13.5px;font-family:inherit;background:var(--bg-soft);
  }
  .field2 textarea{resize:vertical;min-height:80px;}

  table{width:100%;border-collapse:collapse;}
  thead th{
    text-align:left;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--text-faint);
    font-family:'IBM Plex Mono',monospace;font-weight:600;padding:0 22px 12px;border-bottom:1px solid var(--line);
  }
  tbody td{padding:14px 22px;border-bottom:1px solid var(--line);font-size:13.5px;vertical-align:middle;}
  tbody tr:last-child td{border-bottom:0;}
  .thumb-cell{display:flex;align-items:center;gap:12px;}
  .thumb-cell .thumb{width:52px;height:38px;border-radius:8px;flex:none;background:linear-gradient(135deg,var(--violet),var(--gold));background-size:cover;background-position:center;}
  .thumb-cell strong{font-size:13.5px;display:block;}
  .thumb-cell span{font-size:11.5px;color:var(--text-faint);}
  .badge{font-family:'IBM Plex Mono',monospace;font-size:10.5px;padding:4px 10px;border-radius:100px;font-weight:600;}
  .badge.gambar{background:var(--violet-soft);color:var(--violet-deep);}
  .badge.video{background:var(--gold-soft);color:var(--gold);}
  .row-actions{display:flex;gap:8px;}
  .icon-btn{
    width:30px;height:30px;border-radius:8px;border:1px solid var(--line);background:#fff;
    display:flex;align-items:center;justify-content:center;color:var(--text-muted);
  }
  .icon-btn:hover{background:var(--bg-soft);color:var(--text);}
  .empty-note{padding:40px 22px;text-align:center;color:var(--text-faint);font-size:13px;}

  .alert{padding:12px 18px;border-radius:var(--radius-sm);font-size:13px;font-weight:600;margin-bottom:18px;}
  .alert-success{background:var(--green-soft);color:var(--green);}
  .alert-error{background:#fdf1f1;color:#c0392b;}

  @media (max-width:900px){
    .form-grid{grid-template-columns:1fr;}
    .content{padding:22px 16px 50px;}
    .topbar{padding:14px 16px;}
  }
</style>
@stack('styles')
</head>
<body>

<div class="shell">
  <aside class="sidebar">
    <div class="sb-brand">
      <svg class="seal" viewBox="0 0 60 60" fill="none"><circle cx="30" cy="30" r="27" stroke="#b8791f" stroke-width="1.4" stroke-dasharray="2 3"/><circle cx="30" cy="30" r="20" stroke="#6c5ce7" stroke-width="1.4"/><path d="M30 16 L33 26 L44 26 L35 32 L38 43 L30 36 L22 43 L25 32 L16 26 L27 26 Z" fill="#b8791f"/></svg>
      <div>KEDUBES STUDIO<small>Admin Panel</small></div>
    </div>

    <div class="sb-label">Menu</div>
    <nav class="sb-menu">
      <a href="{{ route('admin.konten') }}" class="{{ request()->routeIs('admin.*') ? 'active' : '' }}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
        Kelola Konten
      </a>
    </nav>

    <div class="sb-bottom">
      <div class="sb-user">
        <div class="av"></div>
        <div><strong>{{ auth()->user()->name ?? 'Admin' }}</strong><span>{{ auth()->user()->email ?? '' }}</span></div>
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button type="submit" class="logout" title="Keluar">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
          </button>
        </form>
      </div>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <div>
        <h2>@yield('title', 'Kelola Konten')</h2>
        <div class="path mono">admin/{{ request()->segment(2) }}</div>
      </div>
      <a href="{{ route('home') }}" target="_blank" class="btn-view-site">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14L21 3"/></svg>
        Lihat Situs
      </a>
    </div>

    <div class="content">
      <div class="tabs">
        <a href="{{ route('admin.konten') }}" class="tab-btn {{ request()->routeIs('admin.konten') ? 'active' : '' }}">Pengaturan Umum</a>
        <a href="{{ route('admin.layanan.index') }}" class="tab-btn {{ request()->routeIs('admin.layanan.*') ? 'active' : '' }}">Layanan</a>
        <a href="{{ route('admin.portofolio.index') }}" class="tab-btn {{ request()->routeIs('admin.portofolio.*') ? 'active' : '' }}">Portofolio</a>
        <a href="{{ route('admin.testimoni.index') }}" class="tab-btn {{ request()->routeIs('admin.testimoni.*') ? 'active' : '' }}">Testimoni</a>
      </div>

      @if (session('status'))
        <div class="alert alert-success">{{ session('status') }}</div>
      @endif
      @if ($errors->any())
        <div class="alert alert-error">
          @foreach ($errors->all() as $error) {{ $error }}<br> @endforeach
        </div>
      @endif

      @yield('content')
    </div>
  </div>
</div>

@stack('scripts')
</body>
</html>
