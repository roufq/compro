# Kedubes Studio — Laravel Starter Kit

File-file di sini adalah **migration, model, controller, seeder, dan route**
untuk company profile dinamis Kedubes Studio. Karena environment ini tidak
bisa menjalankan `composer install`, file-file ini perlu ditempel ke project
Laravel yang Anda buat sendiri. Ikuti urutan berikut:

## 1. Buat project Laravel baru

```bash
composer create-project laravel/laravel kedubes-studio
cd kedubes-studio
```

## 2. Install Laravel Breeze (untuk fitur login)

```bash
composer require laravel/breeze --dev
php artisan breeze:install blade
npm install && npm run build
```

## 3. Nonaktifkan register publik

Buka `routes/auth.php`, **hapus atau comment** blok route `register`
(biasanya 2 baris `Route::get('register', ...)` dan
`Route::post('register', ...)`). Ini memastikan hanya 1 admin dari
seeder yang bisa login — tidak ada yang bisa daftar sendiri.

## 4. Salin file dari starter kit ini

| Dari starter kit                          | Ke project Laravel                          |
|--------------------------------------------|----------------------------------------------|
| `database/migrations/*.php`                | `database/migrations/`                        |
| `database/seeders/*.php`                   | `database/seeders/` (timpa `DatabaseSeeder.php`) |
| `app/Models/*.php`                         | `app/Models/`                                  |
| `app/Http/Controllers/PublicController.php`| `app/Http/Controllers/`                        |
| `app/Http/Controllers/Admin/*.php`         | `app/Http/Controllers/Admin/` (buat folder baru) |
| `routes/web.php`                           | `routes/web.php` (timpa file bawaan)           |

## 5. Konfigurasi `.env` & storage

```bash
php artisan storage:link
```
Pastikan `DB_*` di `.env` sudah sesuai database Anda (MySQL/SQLite).

## 6. Migrate & seed admin

```bash
php artisan migrate --seed
```

Ini otomatis membuat 1 akun admin:
- Email: `admin@kedubesstudio.id`
- Password: `ganti-password-ini`

**Wajib ganti password ini** — buka `database/seeders/AdminUserSeeder.php`
sebelum deploy, atau ubah manual lewat tinker:
```bash
php artisan tinker
>>> $u = App\Models\User::first(); $u->password = Hash::make('password-baru'); $u->save();
```

## 7. Views (Blade) — sudah termasuk di starter kit ini

| Dari starter kit                                   | Ke project Laravel                          |
|------------------------------------------------------|------------------------------------------------|
| `resources/views/welcome.blade.php`                  | `resources/views/` (timpa file bawaan)         |
| `resources/views/layouts/admin.blade.php`            | `resources/views/layouts/`                     |
| `resources/views/admin/**`                           | `resources/views/admin/`                        |

`welcome.blade.php` adalah hasil konversi penuh dari desain frontend
(`kedubes-studio.html`) — semua teks, logo, layanan, portofolio (gambar
upload + video YouTube), dan testimoni sudah dinamis, diambil langsung
dari database lewat `PublicController`.

Halaman admin (`resources/views/admin/**`) memakai layout yang sama
persis temanya dengan frontend (warna violet + gold, font Plus Jakarta
Sans/Inter/IBM Plex Mono) supaya terasa satu produk.

Setelah file-file ini disalin, langsung buka:
- `http://project-anda.test/` → tampilan publik dinamis
- `http://project-anda.test/login` → login admin
- `http://project-anda.test/admin/konten` → dashboard "Kelola Konten"


## Ringkasan struktur data

**site_settings** (1 baris saja): logo, nama perusahaan, tagline, judul &
deskripsi hero, kontak.

**services**: title, description, order.

**portfolios**: title, description, category, type (`gambar`/`video`),
image_path (kalau gambar), youtube_url (kalau video — thumbnail & embed
diambil otomatis dari model `Portfolio`).

**testimonials**: name, role, quote, avatar_path, rating.
