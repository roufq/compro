<?php

use App\Http\Controllers\Admin\PortfolioController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\SiteSettingController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\PublicController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Halaman publik — GET / langsung tampil index dinamis
|--------------------------------------------------------------------------
*/
Route::get('/', [PublicController::class, 'index'])->name('home');

/*
|--------------------------------------------------------------------------
| Auth (dari Laravel Breeze) — GET /login tampil form login
| PENTING: hapus/comment route register di routes/auth.php
| supaya tidak ada orang lain bisa daftar akun sendiri.
|--------------------------------------------------------------------------
*/
require __DIR__ . '/auth.php';

/*
|--------------------------------------------------------------------------
| Area admin — dilindungi middleware auth, hanya bisa diakses
| setelah login dengan 1 akun admin dari seeder.
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->prefix('admin')->name('admin.')->group(function () {

    Route::redirect('/', '/admin/konten');

    // Menu "Kelola Konten" — Pengaturan Umum
    Route::get('/konten', [SiteSettingController::class, 'edit'])->name('konten');
    Route::put('/konten', [SiteSettingController::class, 'update'])->name('konten.update');

    // Tab: Layanan
    Route::get('/layanan', [ServiceController::class, 'index'])->name('layanan.index');
    Route::post('/layanan', [ServiceController::class, 'store'])->name('layanan.store');
    Route::put('/layanan/{service}', [ServiceController::class, 'update'])->name('layanan.update');
    Route::delete('/layanan/{service}', [ServiceController::class, 'destroy'])->name('layanan.destroy');

    // Tab: Portofolio
    Route::get('/portofolio', [PortfolioController::class, 'index'])->name('portofolio.index');
    Route::post('/portofolio', [PortfolioController::class, 'store'])->name('portofolio.store');
    Route::put('/portofolio/{portfolio}', [PortfolioController::class, 'update'])->name('portofolio.update');
    Route::delete('/portofolio/{portfolio}', [PortfolioController::class, 'destroy'])->name('portofolio.destroy');

    // Tab: Testimoni
    Route::get('/testimoni', [TestimonialController::class, 'index'])->name('testimoni.index');
    Route::post('/testimoni', [TestimonialController::class, 'store'])->name('testimoni.store');
    Route::put('/testimoni/{testimonial}', [TestimonialController::class, 'update'])->name('testimoni.update');
    Route::delete('/testimoni/{testimonial}', [TestimonialController::class, 'destroy'])->name('testimoni.destroy');
});
