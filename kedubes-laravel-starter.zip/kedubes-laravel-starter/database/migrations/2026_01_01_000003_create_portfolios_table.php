<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('portfolios', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('category')->default('branding')
                ->comment('branding | produk | video | dll — bebas diisi admin');

            // type menentukan kolom mana yang dipakai di bawah ini
            $table->enum('type', ['gambar', 'video'])->default('gambar');

            // dipakai jika type = gambar (upload file ke storage)
            $table->string('image_path')->nullable();

            // dipakai jika type = video (cukup tempel link YouTube, tidak upload file)
            $table->string('youtube_url')->nullable();

            $table->unsignedInteger('order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('portfolios');
    }
};
