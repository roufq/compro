<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Satu-satunya cara akun admin dibuat adalah lewat seeder ini,
     * bukan lewat form register publik (route register sudah dinonaktifkan
     * di routes/auth.php — lihat catatan di README).
     */
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'admin@kedubesstudio.id'],
            [
                'name'     => 'Admin Kedubes Studio',
                // GANTI password ini sebelum deploy ke production!
                'password' => Hash::make('ganti-password-ini'),
            ]
        );
    }
}
