<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteSetting extends Model
{
    protected $fillable = [
        'logo_path', 'company_name', 'tagline',
        'hero_title', 'hero_description',
        'email', 'phone', 'address',
        'instagram_url', 'linkedin_url', 'youtube_url',
    ];

    /**
     * Ambil satu-satunya baris pengaturan, buat default jika belum ada.
     */
    public static function current(): self
    {
        return static::firstOrCreate(['id' => 1], [
            'company_name' => 'Kedubes Studio',
            'tagline' => 'Kedutaan Kreativitas AI',
        ]);
    }

    public function getLogoUrlAttribute(): ?string
    {
        return $this->logo_path ? asset('storage/' . $this->logo_path) : null;
    }
}
