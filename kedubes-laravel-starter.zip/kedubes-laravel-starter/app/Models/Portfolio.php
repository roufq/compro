<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Portfolio extends Model
{
    protected $fillable = [
        'title', 'description', 'category', 'type',
        'image_path', 'youtube_url', 'order',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope('ordered', function ($query) {
            $query->orderBy('order')->orderBy('id', 'desc');
        });
    }

    public function isVideo(): bool
    {
        return $this->type === 'video';
    }

    /**
     * Ambil ID video dari berbagai format link YouTube:
     * - https://youtu.be/XXXXXXXXXXX
     * - https://www.youtube.com/watch?v=XXXXXXXXXXX
     * - https://www.youtube.com/embed/XXXXXXXXXXX
     */
    public function getYoutubeIdAttribute(): ?string
    {
        if (!$this->youtube_url) {
            return null;
        }

        if (preg_match('/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/))([a-zA-Z0-9_-]{11})/', $this->youtube_url, $m)) {
            return $m[1];
        }

        return null;
    }

    /** Thumbnail otomatis dari YouTube, tanpa perlu upload manual */
    public function getYoutubeThumbnailAttribute(): ?string
    {
        return $this->youtube_id
            ? "https://img.youtube.com/vi/{$this->youtube_id}/hqdefault.jpg"
            : null;
    }

    /** Link embed untuk ditampilkan di lightbox frontend */
    public function getYoutubeEmbedAttribute(): ?string
    {
        return $this->youtube_id
            ? "https://www.youtube.com/embed/{$this->youtube_id}"
            : null;
    }

    /** Thumbnail yang dipakai di kartu galeri, otomatis pilih sesuai tipe */
    public function getThumbnailUrlAttribute(): ?string
    {
        return $this->isVideo()
            ? $this->youtube_thumbnail
            : ($this->image_path ? asset('storage/' . $this->image_path) : null);
    }
}
