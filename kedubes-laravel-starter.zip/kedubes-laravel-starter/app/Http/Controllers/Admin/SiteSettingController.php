<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteSetting;
use Illuminate\Http\Request;

class SiteSettingController extends Controller
{
    public function edit()
    {
        $settings = SiteSetting::current();
        return view('admin.settings.edit', compact('settings'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'company_name'      => 'required|string|max:255',
            'tagline'           => 'nullable|string|max:255',
            'hero_title'        => 'nullable|string|max:255',
            'hero_description'  => 'nullable|string',
            'email'             => 'nullable|email',
            'phone'             => 'nullable|string|max:50',
            'address'           => 'nullable|string|max:255',
            'instagram_url'     => 'nullable|url',
            'linkedin_url'      => 'nullable|url',
            'youtube_url'       => 'nullable|url',
            'logo'              => 'nullable|image|max:2048',
        ]);

        $settings = SiteSetting::current();

        if ($request->hasFile('logo')) {
            $data['logo_path'] = $request->file('logo')->store('logo', 'public');
        }

        $settings->update($data);

        return back()->with('status', 'Pengaturan berhasil disimpan.');
    }
}
