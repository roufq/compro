<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Portfolio;
use Illuminate\Http\Request;

class PortfolioController extends Controller
{
    public function index()
    {
        return view('admin.portfolios.index', ['portfolios' => Portfolio::all()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);

        if ($data['type'] === 'gambar' && $request->hasFile('image')) {
            $data['image_path'] = $request->file('image')->store('portfolio', 'public');
        }

        Portfolio::create($data);

        return back()->with('status', 'Karya berhasil ditambahkan.');
    }

    public function update(Request $request, Portfolio $portfolio)
    {
        $data = $this->validated($request);

        if ($data['type'] === 'gambar' && $request->hasFile('image')) {
            $data['image_path'] = $request->file('image')->store('portfolio', 'public');
        }

        $portfolio->update($data);

        return back()->with('status', 'Karya berhasil diperbarui.');
    }

    public function destroy(Portfolio $portfolio)
    {
        $portfolio->delete();

        return back()->with('status', 'Karya berhasil dihapus.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'category'    => 'required|string|max:100',
            'type'        => 'required|in:gambar,video',
            // wajib diisi salah satu tergantung tipe — divalidasi manual di form/JS,
            // di sini dibuat nullable supaya submit tidak gagal untuk tipe yang tidak dipakai
            'image'       => 'nullable|image|max:4096',
            'youtube_url' => 'nullable|url',
            'order'       => 'nullable|integer',
        ]);
    }
}
