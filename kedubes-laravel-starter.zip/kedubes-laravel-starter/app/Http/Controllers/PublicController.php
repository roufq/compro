<?php

namespace App\Http\Controllers;

use App\Models\Portfolio;
use App\Models\Service;
use App\Models\SiteSetting;
use App\Models\Testimonial;

class PublicController extends Controller
{
    /**
     * GET /  — halaman utama, semua konten diambil dari database.
     */
    public function index()
    {
        $settings = SiteSetting::current();
        $services = Service::all();
        $portfolios = Portfolio::all();
        $testimonials = Testimonial::all();

        return view('welcome', compact('settings', 'services', 'portfolios', 'testimonials'));
    }
}
